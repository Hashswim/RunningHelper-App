package com.swdm2020gachon.mptp;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;


public class walking extends AppCompatActivity implements SensorEventListener{

    private SensorManager sensorManager;
    private Sensor stepCountSensor;
    TextView StepCount;

    Button half = (Button) findViewById(R.id.place1);
    Button one = (Button) findViewById(R.id.place2);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.walking);

        StepCount = (TextView)findViewById(R.id.StepCount);
        sensorManager = (SensorManager)getSystemService((Context.SENSOR_SERVICE));
        stepCountSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        if(stepCountSensor == null){
            Toast.makeText(this,"No Step Detect Sensor", Toast.LENGTH_SHORT).show();
        }

        half.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //fragment 호출 50% 달성 시의 정보
            }
        });
        one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //fragment 호출 100% 달성 시의 정보
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener((SensorEventListener) this,stepCountSensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause(){
        super.onPause();
        sensorManager.unregisterListener((SensorEventListener) this);
    }

    @Override
    public void onSensorChanged(SensorEvent event){
        if(event.sensor.getType() == Sensor.TYPE_STEP_COUNTER){
            StepCount.setText("Step Count : " + String.valueOf(event.values[0]));
            //event.values[0] 이 걸음 수
            Intent intent = getIntent();
            ProgressBar progressBar = (ProgressBar)findViewById(R.id.progressbar);
            progressBar.setProgress((int) ((intent.getIntExtra("distance",1)/event.values[0])*100));
            //(intent.getIntExtra("distance",1)/event.values[0])*100)(진행도 %)이 50, 100일때 정보 표시 fragment 호출
            if(((intent.getIntExtra("distance",1)/event.values[0])*100) >= 50){
                half.setEnabled(true);
            }
            if(((intent.getIntExtra("distance",1)/event.values[0])*100) >= 100){
                one.setEnabled(true);
            }
        }
    }



    @Override
    public  void onAccuracyChanged(Sensor sensor, int accuracy){

    }
}
